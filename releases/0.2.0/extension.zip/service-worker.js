// src/contracts/index.ts
var categories = ["seo", "structured", "geo", "conversion", "performance"];

// src/rules/structured-evidence.ts
function productEvidence(snapshot) {
  const s = snapshot.schema;
  const group = s.groups?.selected !== void 0 && s.groups.selected !== null ? s.groups.products[s.groups.selected] : void 0;
  if (s.products.length || s.groups?.products.length || s.truncated || !s.microdata?.products.length && !s.microdata?.truncated) {
    const selected = s.selected === null ? void 0 : s.products[s.selected];
    return { product: selected ?? group, source: s.products.length || s.groups?.products.length ? "jsonld" : "none", ambiguous: selected ? s.ambiguous : group ? false : s.ambiguous || !!s.groups?.ambiguous, truncated: s.truncated, count: s.products.length + (s.groups?.products.length ?? 0) };
  }
  const m = s.microdata;
  return { product: m.selected === null ? void 0 : m.products[m.selected], source: "microdata", ambiguous: m.ambiguous, truncated: m.truncated, count: m.products.length };
}
function schemaStock(value) {
  const term = value.replace(/^https?:\/\/schema\.org\//, "");
  switch (term) {
    case "InStock":
      return "in_stock";
    case "LimitedAvailability":
      return "low_stock";
    case "OutOfStock":
    case "SoldOut":
      return "out_of_stock";
    case "BackOrder":
      return "backorder";
    case "PreOrder":
    case "PreSale":
      return "preorder";
    default:
      return "unknown";
  }
}
function stockLine(s) {
  return `${s.channel === "unspecified" ? s.contextLabel || "Page availability" : s.channel === "delivery" ? "Delivery" : `Pickup${s.location ? " \u2014 " + s.location : ""}`}: ${s.rawText}`;
}
function compareStock(offer, observations, truncated = false) {
  const unknown = (explanation) => ({ status: "not_evaluated", explanation, evidence: observations.slice(0, 4).map(stockLine) });
  if (truncated) return unknown("Stock capture reached its bound; a complete same-context comparison is unavailable.");
  const expected = schemaStock(offer.availability);
  if (expected === "unknown") return unknown("The structured availability cannot be mapped to a supported stock state.");
  const channel = offer.channel ?? "unspecified", location2 = (offer.location ?? "").trim().toLowerCase();
  const eligible = observations.filter((o) => o.source === "visible" && o.confidence === "high" && o.status !== "unknown");
  const candidates = observations.filter((o) => {
    if ((o.channel ?? "unspecified") !== channel) return false;
    const at = (o.location ?? "").trim().toLowerCase();
    if (channel === "pickup" && (!location2 || !at)) return false;
    if (location2) return at === location2;
    if (at) return false;
    return channel !== "unspecified" || !o.contextLabel;
  });
  if (candidates.some((o) => o.confidence !== "high" || o.status === "unknown")) return unknown("Potentially matching visible stock evidence is ambiguous or low-confidence; no confirmed comparison.");
  const matched = candidates.filter((o) => eligible.includes(o));
  if (matched.length !== 1) {
    if (channel === "unspecified" && !location2 && eligible.some((o) => o.channel !== "unspecified" || !!o.location || !!o.contextLabel)) return unknown("The general structured Offer does not identify a fulfilment channel/location. Delivery and pickup statements are preserved separately; no cross-context mismatch is asserted.");
    return unknown(matched.length > 1 ? "Multiple visible statements match this scope; a unique, non-conflicting same-context statement is required." : "No uniquely aligned visible stock statement exists for this Offer fulfilment/location scope.");
  }
  if (channel === "unspecified" && !location2 && observations.length !== 1) return unknown("Multiple fulfilment observations prevent a unique general-Offer comparison.");
  const observed = matched[0], available = (s) => s === "in_stock" || s === "low_stock";
  const evidence = [stockLine(observed), `Structured (${offer.source ?? "jsonld"}): ${offer.availability}`];
  if (expected === observed.status || available(expected) && available(observed.status)) return { status: "pass", explanation: "Structured and visible availability are compatible in the same fulfilment/location scope. Low-stock detail is retained.", evidence };
  if (available(expected) !== available(observed.status)) return { status: "fail", explanation: "Structured and visible availability contradict in the same explicitly aligned fulfilment/location scope.", evidence };
  return unknown("The detailed non-immediate stock states differ; equivalence or a confirmed contradiction is not established.");
}

// src/rules/index.ts
var RULES = [
  ["SEO-01", "seo", "Page title and identity", 3, "medium"],
  ["SEO-02", "seo", "Meta description", 1, "low"],
  ["SEO-03", "seo", "H1 and heading structure", 2, "medium"],
  ["SEO-04", "seo", "Canonical declaration", 2, "medium"],
  ["SEO-05", "seo", "DOM robots directives", 3, "high"],
  ["SEO-06", "seo", "Visible product description", 3, "medium"],
  ["SEO-07", "seo", "Product image alternative text", 2, "medium"],
  ["SD-01", "structured", "Product structured data presence", 4, "high"],
  ["SD-02", "structured", "Product identity fields", 3, "medium"],
  ["SD-03", "structured", "Offer price and currency", 4, "high"],
  ["SD-04", "structured", "Availability semantics", 2, "medium"],
  ["SD-05", "structured", "Price consistency", 5, "critical"],
  ["SD-06", "structured", "Availability consistency", 4, "high"],
  ["SD-07", "structured", "Entity and variant consistency", 3, "high"],
  ["GEO-01", "geo", "Clear product identity and brand", 3, "medium"],
  ["GEO-02", "geo", "Category and intended use context", 1, "low"],
  ["GEO-03", "geo", "Specifications and attributes", 2, "medium"],
  ["GEO-04", "geo", "Readable product information", 3, "medium"],
  ["GEO-05", "geo", "Decision-support context", 1, "low", true],
  ["UX-01", "conversion", "Product imagery", 3, "medium"],
  ["UX-02", "conversion", "Visible price and stock information", 3, "medium"],
  ["UX-03", "conversion", "Primary purchase action", 4, "high"],
  ["UX-04", "conversion", "Variant option accessibility", 2, "medium"],
  ["UX-05", "conversion", "Delivery and returns information", 2, "low"],
  ["PERF-01", "performance", "Product image sizing", 2, "medium"],
  ["PERF-02", "performance", "Image dimension hints", 2, "medium"],
  ["PERF-03", "performance", "Image loading hints", 1, "low"],
  ["PERF-04", "performance", "DOM and resource complexity", 1, "low", true]
].map(([id, category, title, weight, severity, advisory]) => ({ id, category, title, weight, severity, advisory: Boolean(advisory) }));
var text = (v) => typeof v === "string" ? v.trim() : "";
var has = (v) => text(v).length > 0;
var product = (s) => s.classification === "product";
var ev = (...values) => values.filter((v) => typeof v === "string" ? has(v) : v !== void 0 && v !== null).map(String).slice(0, 4);
var decimal = (v) => /^(?:0|[1-9]\d*)(?:\.\d+)?$/.test(text(v)) && Number(text(v)) > 0;
var currency = (v) => /^[A-Z]{3}$/.test(text(v).toUpperCase()) && Intl.supportedValuesOf("currency").includes(text(v).toUpperCase());
var normalDecimal = (v) => {
  const [a, b = ""] = text(v).split(".");
  return `${a.replace(/^0+(?=\d)/, "")}.${b.replace(/0+$/, "") || "0"}`;
};
var allowedAvailability = "InStock|OutOfStock|PreOrder|BackOrder|Discontinued|LimitedAvailability|OnlineOnly|InStoreOnly|SoldOut|PreSale|Reserved";
var availability = (v) => new RegExp(`^(?:https?:\\/\\/schema\\.org\\/)?(?:${allowedAvailability})$`).test(text(v));
var recommendation = {
  "SEO-01": "Provide a document title that identifies the product; use the product name only as supporting identity evidence.",
  "SEO-02": "Add a concise, unique meta description.",
  "SEO-03": "Review heading hierarchy and ensure the product heading is clear.",
  "SEO-04": "Declare one intentional, valid canonical URL.",
  "SEO-05": "Review robots directives against the intended indexing policy.",
  "SEO-06": "Expose a readable product description in the page content.",
  "SEO-07": "Give relevant product images meaningful alternative text.",
  "SD-01": "Publish one parseable Product entity for the confirmed product.",
  "SD-02": "Add the selected Product name and, where applicable, description and image fields.",
  "SD-03": "Use valid positive decimal offer prices and three-letter ISO currency codes.",
  "SD-04": "Use one anchored schema.org availability enum for the applicable offer.",
  "SD-05": "Align the current single Offer with the visible price and currency.",
  "SD-06": "Align the current Offer availability with the clearly visible stock state.",
  "SD-07": "Resolve the current Product entity and keep variant data unambiguous.",
  "GEO-01": "Show a clear product name and brand where relevant.",
  "GEO-02": "Expose a breadcrumb/category or explicit intended-use statement.",
  "GEO-03": "Present relevant specifications in accessible text.",
  "GEO-04": "Keep decision-relevant product information readable and accessible.",
  "GEO-05": "Consider adding explicit benefits, compatibility, FAQ, or warranty context.",
  "UX-01": "Show at least one relevant, successfully loaded product image.",
  "UX-02": "Show the current price and stock state when the item is purchasable.",
  "UX-03": "Expose an accessible purchase action for an in-stock purchasable item.",
  "UX-04": "Label and expose variant controls when variants require selection.",
  "UX-05": "Provide delivery and returns access for shippable products.",
  "PERF-01": "Review strong image oversizing signals against measured evidence.",
  "PERF-02": "Provide image dimensions or reliable reserved space hints.",
  "PERF-03": "Avoid eager-loading clearly offscreen images while preserving hero loading.",
  "PERF-04": "Treat DOM/resource counts as local diagnostics and calibrate thresholds before action."
};
function evaluate(snapshot) {
  const p = snapshot.product, structured = productEvidence(snapshot), selected = structured.product;
  const sourceLabel = structured.source === "microdata" ? "Microdata (supported subset)" : "JSON-LD";
  const observations = p.stockObservations ?? (p.availability !== "unknown" ? [{ channel: "unspecified", contextLabel: "", status: p.availability, rawText: p.availability.replaceAll("_", " "), source: "visible", confidence: "high" }] : []);
  const results = {};
  const set = (id, status, applicability, confidence, explanation, evidence, reasonCode) => {
    results[id] = { status, applicability, confidence, explanation, evidence, reasonCode };
  };
  const unknown = (id, why = "Evidence is incomplete or the current entity cannot be resolved.") => set(id, "not_evaluated", snapshot.classification === "ambiguous" || snapshot.classification === "blocked" ? "unknown" : product(snapshot) ? "unknown" : "not_applicable", "low", why, [], "INSUFFICIENT_EVIDENCE");
  if (!product(snapshot)) {
    for (const r of RULES) unknown(r.id, snapshot.classification === "blocked" ? "Access/security verification screen detected; product content is unavailable." : snapshot.classification === "ambiguous" ? "Product page identity is unconfirmed; no page-specific assessment was made." : "The page is not classified as a product page.");
  } else {
    set("SEO-01", has(snapshot.title) ? "pass" : "fail", "applicable", has(snapshot.title) ? "high" : "medium", has(snapshot.title) ? "The document title is present." : "The document title is absent; product name cannot substitute for it.", ev(snapshot.title, p.name), has(snapshot.title) ? "TITLE_PRESENT" : "TITLE_MISSING");
    set("SEO-02", has(snapshot.metaDescription) ? "pass" : "warning", "applicable", "high", has(snapshot.metaDescription) ? "A meta description is present." : "The meta description is absent.", ev(snapshot.metaDescription), has(snapshot.metaDescription) ? "META_PRESENT" : "META_MISSING");
    set("SEO-03", snapshot.h1.length === 0 ? "warning" : "pass", "applicable", "high", snapshot.h1.length === 0 ? "No H1 was observed." : "A product H1 is present; multiple H1s are advisory only.", snapshot.h1.slice(0, 2), snapshot.h1.length === 0 ? "H1_MISSING" : "H1_PRESENT");
    const canon = snapshot.canonical.count === 1 && snapshot.canonical.valid;
    set("SEO-04", canon ? "pass" : "warning", "applicable", "high", canon ? "One valid canonical was observed." : "Canonical declaration is absent, invalid, or conflicting.", [String(snapshot.canonical.count), String(snapshot.canonical.valid)], canon ? "CANONICAL_VALID" : "CANONICAL_REVIEW");
    const noindex = snapshot.robots.some((x) => x.toLowerCase().split(/[\s,;]+/).some((token) => token === "noindex" || token === "none"));
    set("SEO-05", noindex ? "warning" : "pass", "applicable", "high", noindex ? "A DOM robots restriction was observed." : "No DOM noindex restriction was observed.", snapshot.robots.slice(0, 3), noindex ? "ROBOTS_RESTRICTION" : "ROBOTS_CLEAR");
    set("SEO-06", has(p.description) ? "pass" : "warning", "applicable", has(p.description) ? "high" : "medium", has(p.description) ? p.descriptionSource === "expandable" ? "Product description is available in an explicitly linked expandable panel." : "A visible product description is represented." : "A visible product description was not established.", ev(p.description), has(p.description) ? "DESCRIPTION_PRESENT" : "DESCRIPTION_MISSING");
    const badAlt = p.images.filter((i) => !has(i.alt)).length;
    set("SEO-07", p.images.length && badAlt === 0 ? "pass" : "warning", "applicable", p.images.length ? "high" : "medium", p.images.length && badAlt === 0 ? "Product image alt text is present." : "Product images or meaningful alt text are missing.", [String(p.images.length), String(badAlt)], "IMAGE_ALT");
    const hasProduct = !!selected;
    set("SD-01", hasProduct ? "pass" : "fail", "applicable", "high", hasProduct ? `${sourceLabel}: a matched Product entity was captured. No full rich-result eligibility claim.` : "No supported Product JSON-LD or microdata entity was established on this product page.", [sourceLabel, String(structured.count)], hasProduct ? "SCHEMA_PRODUCT" : "SCHEMA_PRODUCT_MISSING");
    const structuredUnknown = structured.truncated || structured.ambiguous || !selected;
    if (!selected) {
      for (const id of ["SD-02", "SD-03", "SD-04", "SD-05", "SD-06", "SD-07"]) unknown(id, "No selected structured-data Product entity was established.");
    } else if (structuredUnknown) {
      for (const id of ["SD-02", "SD-03", "SD-04", "SD-05", "SD-06", "SD-07"]) unknown(id, structured.truncated ? "The selected structured-data source is partial or outside the supported subset; affected checks were not evaluated." : "The current structured-data entity is ambiguous.");
    } else {
      set("SD-02", has(selected.name) ? has(selected.description) && selected.image ? "pass" : "warning" : "fail", "applicable", "high", has(selected.name) ? has(selected.description) && selected.image ? "Selected Product identity and useful fields are present." : "Selected Product has a name but description or image is missing." : "Selected Product has no name.", ev(selected.name, selected.description, selected.brand, selected.sku), has(selected.name) ? has(selected.description) && selected.image ? "SCHEMA_IDENTITY_COMPLETE" : "SCHEMA_OPTIONAL_FIELDS_MISSING" : "SCHEMA_NAME_MISSING");
      const offers = selected.offers;
      const valid = offers.filter((o) => o.type === "Offer" && decimal(o.price) && currency(o.currency));
      const aggregate = offers.filter((o) => o.type === "AggregateOffer");
      const ranges = aggregate.some((o) => decimal(o.lowPrice) && decimal(o.highPrice) && currency(o.currency) && Number(normalDecimal(o.lowPrice)) <= Number(normalDecimal(o.highPrice)));
      const purchaseSignal = p.cartEnabled || p.availability !== "unknown" || has(p.price);
      const sd03 = valid.length || ranges ? "pass" : offers.length ? "fail" : purchaseSignal ? "warning" : "not_evaluated";
      set("SD-03", sd03, offers.length || purchaseSignal ? "applicable" : "unknown", "high", sd03 === "pass" ? "A valid positive price/currency or AggregateOffer range was found." : sd03 === "warning" ? "A purchasable product has no offer." : "Offer price/currency evidence is invalid or incomplete.", offers.map((o) => `${o.type}:${o.price}/${o.currency}`).slice(0, 3), sd03 === "pass" ? "SCHEMA_OFFER_VALID" : sd03 === "warning" ? "SCHEMA_OFFER_MISSING" : "SCHEMA_OFFER_INVALID");
      const offerForAvailability = offers.find((o) => o.type === "Offer");
      const av = offerForAvailability && availability(offerForAvailability.availability);
      set("SD-04", av ? "pass" : offers.length ? "warning" : "not_evaluated", offers.length ? "applicable" : "unknown", "high", av ? "A recognized anchored availability enum was found." : "Offer availability is missing or unsupported.", offers.map((o) => o.availability).slice(0, 3), av ? "SCHEMA_AVAILABILITY_VALID" : "SCHEMA_AVAILABILITY_REVIEW");
      const one = offers.length === 1 && offers[0].type === "Offer" && (!offers[0].channel || offers[0].channel === "unspecified") && !offers[0].location && selected.matched && p.priceReliable && (p.priceKind === void 0 || p.priceKind === "exact") && (p.currencySource === void 0 || p.currencySource === "visible") && decimal(p.price) && currency(p.currency) && decimal(offers[0].price) && currency(offers[0].currency);
      const same = one && normalDecimal(offers[0].price) === normalDecimal(p.price) && offers[0].currency.toUpperCase() === p.currency.toUpperCase();
      const comparable = one && offers[0].currency.toUpperCase() === p.currency.toUpperCase();
      set("SD-05", same ? "pass" : comparable ? "fail" : "not_evaluated", one && comparable ? "applicable" : "unknown", one && comparable ? "high" : "low", same ? "Current visible and structured prices match exactly." : comparable ? "Current visible and structured prices differ." : "A reliable same-entity, same-currency current Offer comparison was not established.", ev(p.price, p.currency, offers[0]?.price, offers[0]?.currency), "PRICE_COMPARISON");
      if (offers.length !== 1 || offers[0].type !== "Offer" || !selected.matched) unknown("SD-06", "A unique same-product/variant Offer was not established.");
      else {
        const comparison = compareStock(offers[0], observations, !!p.stockTruncated);
        set("SD-06", comparison.status, comparison.status === "not_evaluated" ? "unknown" : "applicable", comparison.status === "not_evaluated" ? "low" : "high", comparison.explanation, comparison.evidence, "AVAILABILITY_COMPARISON");
      }
      set("SD-07", "pass", "applicable", "medium", `${sourceLabel}: the current Product entity is uniquely resolved; separate sources were not merged.`, [String(structured.count), sourceLabel], "ENTITY_CONSISTENT");
    }
    set("GEO-01", has(p.name) ? "pass" : "warning", "applicable", has(p.name) ? "high" : "medium", has(p.name) ? "Product identity is present." : "Product identity is incomplete.", ev(p.name, p.brand), "GEO_IDENTITY");
    set("GEO-02", has(p.category) ? "pass" : "not_evaluated", has(p.category) ? "applicable" : "unknown", "medium", has(p.category) ? "A category context is present." : "No category context was established.", ev(p.category), "GEO_CATEGORY");
    set("GEO-03", p.specifications.length ? "pass" : "not_evaluated", p.specifications.length ? "applicable" : "unknown", "medium", p.specifications.length ? "Specifications are represented." : "Product-type applicability for specifications was not established.", p.specifications.slice(0, 3), "GEO_SPECS");
    set("GEO-04", has(p.description) || p.specifications.length ? "pass" : "not_evaluated", has(p.description) || p.specifications.length ? "applicable" : "unknown", "medium", "Readable product information was " + (has(p.description) || p.specifications.length ? "represented." : "not established."), ev(p.description, ...p.specifications), "GEO_READABLE");
    set("GEO-05", p.context.length ? "pass" : "not_evaluated", p.context.length ? "applicable" : "unknown", "medium", p.context.length ? "Decision-support context is present." : "Optional decision-support context was not established.", p.context.slice(0, 3), "GEO_CONTEXT_OPTIONAL");
    set("UX-01", p.images.some((i) => i.loaded) ? "pass" : "warning", "applicable", "high", p.images.some((i) => i.loaded) ? "Loaded product imagery is represented." : "Product imagery is absent or not loaded.", [String(p.images.length)], "UX_IMAGES");
    const stockPresent = observations.some((o) => o.source === "visible" && o.confidence !== "low" && o.status !== "unknown");
    const purchasable = p.cartEnabled || stockPresent;
    set("UX-02", purchasable ? has(p.price) && stockPresent ? "pass" : "warning" : "not_evaluated", purchasable ? "applicable" : "unknown", "high", has(p.price) && stockPresent ? "Visible pricing and independent stock statements were captured, preserving each fulfilment/location context." : "Visible price and stock evidence was not fully established.", ev(p.price, ...observations.map(stockLine)), "UX_PRICE_STOCK");
    const purchaseApplicable = p.cartEnabled;
    set("UX-03", p.cart && p.cartEnabled ? "pass" : "not_evaluated", purchaseApplicable ? "applicable" : p.availability === "out_of_stock" ? "not_applicable" : "unknown", purchaseApplicable ? "high" : "medium", purchaseApplicable ? "An enabled purchase control is present. This does not independently confirm stock availability." : "An enabled purchase control could not be established; options or stock may need checking.", [String(p.cart), String(p.cartEnabled)], "UX_PURCHASE_ACTION");
    set("UX-04", p.variants > 0 ? p.variantsLabelled ? "pass" : "warning" : "not_evaluated", p.variants > 0 ? "applicable" : "not_applicable", "high", p.variants > 0 ? p.variantsLabelled ? "Variant labels are represented." : "Variant labeling was not established." : "No variants were established.", [String(p.variants)], "UX_VARIANTS");
    const policiesPresent = p.shipping && p.returns && p.shippable !== false;
    set("UX-05", policiesPresent ? "pass" : p.shippable === true ? "warning" : "not_evaluated", policiesPresent || p.shippable === true ? "applicable" : p.shippable === false ? "not_applicable" : "unknown", "high", policiesPresent ? "Delivery and returns information is accessible through page text or links; the policy terms were not audited." : p.shippable === true ? "Delivery/returns access was not fully established." : "Shipping applicability is not confirmed.", [String(p.shipping), String(p.returns)], "UX_DELIVERY_RETURNS");
    const known = p.images.filter((i) => i.naturalWidth > 0 && i.naturalHeight > 0 && i.width > 0 && i.height > 0);
    const oversized = known.some((i) => i.naturalWidth > i.width * Math.max(1, snapshot.technical.dpr) * 2 || i.naturalHeight > i.height * Math.max(1, snapshot.technical.dpr) * 2);
    set("PERF-01", known.length ? oversized ? "warning" : "pass" : "not_evaluated", known.length ? "applicable" : "unknown", known.length ? "high" : "low", "Local image dimension observations were " + (known.length ? "available." : "not available."), [String(known.length)], oversized ? "PERF_IMAGE_OVERSIZED" : "PERF_IMAGE_SIZE");
    const hinted = p.images;
    set("PERF-02", hinted.length ? hinted.every((i) => i.dimensionHints) ? "pass" : "warning" : "not_evaluated", hinted.length ? "applicable" : "unknown", hinted.length ? "high" : "low", hinted.length ? "Explicit dimension or aspect-ratio hints were inspected; layout shift was not measured." : "Image dimension evidence was not available.", [String(hinted.length)], "PERF_DIMENSION_HINTS");
    const eager = p.images.some((i) => i.offscreen && !i.lazy);
    set("PERF-03", p.images.length ? eager ? "warning" : "pass" : "not_evaluated", p.images.length ? "applicable" : "unknown", "medium", "Image loading hints were " + (eager ? "a possible offscreen eager-loading opportunity." : "observed without a strong issue."), [String(p.images.length)], "PERF_LOADING_HINTS");
    const complex = snapshot.technical.domCount > 3e3 || snapshot.technical.scripts > 30 || snapshot.technical.styles > 20;
    set("PERF-04", complex ? "warning" : "pass", "applicable", "medium", "Local technical counts are advisory observations, not a performance audit.", [String(snapshot.technical.domCount), String(snapshot.technical.scripts), String(snapshot.technical.styles)], complex ? "TECHNICAL_COMPLEXITY" : "TECHNICAL_COUNTS");
    if (selected && !structured.truncated && results["SD-05"]?.status === "not_evaluated") {
      const why = [];
      if (selected.offers[0]?.channel && selected.offers[0].channel !== "unspecified" || selected.offers[0]?.location) why.push("The Offer is fulfilment/location scoped, but the visible price scope is not independently established");
      if (selected.offers.length !== 1) why.push("No unique current Offer is aligned to the selected variant");
      if (p.priceKind === "from" || p.priceKind === "range") why.push("A starting or range price is displayed");
      if (p.currencySource === "metadata") why.push("Currency is supplied by metadata rather than an independent visible ISO code");
      if (!p.currency) why.push("Visible currency is not independently identified");
      if (!p.price) why.push("No unambiguous visible price amount was captured");
      if (why.length) results["SD-05"].explanation = why.join(". ") + ". No confirmed price mismatch is asserted.";
    }
    if (selected && !structured.truncated && results["SD-06"]?.status === "not_evaluated" && observations.length === 0) results["SD-06"].explanation = "No explicit visible stock statement was identified. An enabled purchase button alone does not confirm stock availability.";
    if (p.shipping && !p.returns && results["UX-05"]) {
      results["UX-05"].confidence = "low";
      results["UX-05"].explanation = "Delivery information is linked. Returns access was not established by supported selectors; this is not proof of a missing policy.";
    }
    if (has(p.price) && !stockPresent && results["UX-02"]) {
      results["UX-02"].confidence = "low";
      results["UX-02"].explanation = "A price amount is visible; an explicit stock statement was not identified. This is not a confirmed stock problem.";
    }
    if (!p.description && snapshot.incomplete.some((x) => /description/i.test(x))) unknown("SEO-06", "A readable description could not be established by supported selectors; absence is not confirmed.");
    if (!p.images.length && snapshot.incomplete.some((x) => /images/i.test(x))) for (const id of ["SEO-07", "UX-01"]) unknown(id, "Product gallery capture is unavailable; absence is not confirmed.");
    if (!p.price && snapshot.incomplete.some((x) => /price/i.test(x))) unknown("UX-02", "Visible pricing was missing or ambiguous; no confirmed absence judgment.");
    if (p.images.length && !p.images.some((i) => i.loaded)) unknown("UX-01", "Product images may still be loading; a broken-image conclusion is not established.");
    if (p.images.some((i) => !i.dimensionHints) && results["PERF-02"]) {
      results["PERF-02"].confidence = "low";
      results["PERF-02"].explanation = "Explicit dimension/aspect-ratio hints were not found; stylesheet reservations and layout shifts were not measured.";
    }
    if (snapshot.incomplete.includes("DOM selection limit")) for (const r of RULES.filter((x) => x.category !== "structured")) unknown(r.id, "DOM selection was truncated; no absence or consistency judgment.");
    if (structured.count > 0 && !selected) unknown("SD-01", "Product objects exist, but none is confidently matched to the current page.");
    if (!selected && snapshot.incomplete.some((x) => x.startsWith("Unsupported product structured-data format"))) unknown("SD-01", "Possible product markup outside the supported JSON-LD/Product-Offer microdata subset was detected. A missing-schema defect is not confirmed.");
    if (structured.truncated) for (const id of ["SD-01", "SD-02", "SD-03", "SD-04", "SD-05", "SD-06", "SD-07"]) unknown(id, "Structured-data limits were reached; missing fields are unknown, not absent.");
    if (snapshot.unstable) for (const id of ["SD-05", "SD-06"]) unknown(id, "Page state was unstable; reanalyse manually.");
    if (selected && !structured.truncated && p.variants > 0) for (const id of ["SD-05", "SD-06"]) unknown(id, "Current variant alignment is not proven; no confirmed comparison.");
    if (structured.source === "jsonld" && snapshot.schema.parseErrors > 0 && selected && !structured.truncated) set("SD-01", "pass", "applicable", "high", "Selected Product is parseable. Other malformed JSON-LD blocks are diagnostic only.", [String(snapshot.schema.parseErrors)], "SELECTED_PRODUCT_VALID");
  }
  if (product(snapshot) && selected?.kind === "group" && !structured.truncated && !structured.ambiguous) {
    set("SD-01", "pass", "applicable", "high", "A matched ProductGroup family was captured. The selected variant is not established; this is not full rich-result eligibility validation.", ev(selected.name, String(selected.variantCount ?? 0)), "SCHEMA_FAMILY");
    set("SD-02", has(selected.name) ? "pass" : "fail", "applicable", "high", has(selected.name) ? "The matched ProductGroup has a family name. Shared image/description are optional here; variants may declare their own fields. This does not certify each variant's completeness." : "The matched ProductGroup has no family name.", ev(selected.name, selected.description, selected.brand), "FAMILY_IDENTITY");
    const offers = selected.offers;
    const valid = offers.length > 0 && offers.every((o) => o.type === "Offer" ? decimal(o.price) && currency(o.currency) : o.type === "AggregateOffer" && decimal(o.lowPrice) && decimal(o.highPrice) && currency(o.currency) && Number(o.lowPrice) <= Number(o.highPrice));
    set("SD-03", valid ? "pass" : offers.length ? "fail" : "not_evaluated", offers.length ? "applicable" : "unknown", offers.length ? "high" : "low", "Captured family offers were checked individually for valid price/currency; they were not treated as a selected-size price.", offers.slice(0, 3).map((o) => `${o.type}:${o.price}/${o.currency}`), valid ? "FAMILY_OFFERS_VALID" : "FAMILY_OFFERS_REVIEW");
    const ordinary = offers.filter((o) => o.type === "Offer"), av = ordinary.length > 0 && ordinary.every((o) => availability(o.availability));
    set("SD-04", av ? "pass" : ordinary.length ? "warning" : "not_evaluated", ordinary.length ? "applicable" : "unknown", ordinary.length ? "high" : "low", "Captured family Offer availability enums were checked, not actual inventory or current-size availability.", ordinary.slice(0, 3).map((o) => o.availability), av ? "FAMILY_AVAILABILITY_VALID" : "FAMILY_AVAILABILITY_REVIEW");
    for (const id of ["SD-05", "SD-06", "SD-07"]) unknown(id, "ProductGroup family recognised, but no current variant is independently aligned. Normal size variants are not conflicting Product objects; no selected-price/stock comparison is asserted.");
  }
  return RULES.map((r) => {
    const x = results[r.id] ?? { status: "not_evaluated", applicability: "unknown", confidence: "low", explanation: "No bounded evidence was available.", evidence: [], reasonCode: "INSUFFICIENT_EVIDENCE" };
    return { method: r.id === "SD-05" || r.id === "SD-06" ? "comparison" : r.category === "structured" || /^SEO-0[1-5]$/.test(r.id) ? "standard" : "rendered", ruleId: r.id, category: r.category, title: r.title, status: x.status, severity: r.severity, confidence: x.confidence, applicability: x.applicability, weight: r.weight, advisory: !!r.advisory, explanation: x.explanation, evidence: (x.evidence ?? []).map((v) => String(v).slice(0, 240)), recommendation: recommendation[r.id], reasonCode: x.reasonCode };
  }).sort((a, b) => {
    const rank = (f) => f.status === "fail" ? 0 : f.status === "warning" ? 1 : f.status === "pass" ? 2 : 3;
    const sev = (s) => ({ critical: 4, high: 3, medium: 2, low: 1, info: 0 })[s];
    return rank(a) - rank(b) || sev(b.severity) - sev(a.severity) || { high: 3, medium: 2, low: 1 }[b.confidence] - { high: 3, medium: 2, low: 1 }[a.confidence] || b.weight - a.weight || a.ruleId.localeCompare(b.ruleId);
  });
}
var ruleIds = RULES.map((r) => r.id);

// src/scoring/index.ts
var DEFAULT_WEIGHTS = { seo: 25, structured: 25, geo: 20, conversion: 20, performance: 10 };
var FACTOR = { pass: 1, warning: 0.5, fail: 0 };
var MIN_RULES = 2;
var MIN_COVERAGE = 0.5;
var statuses = /* @__PURE__ */ new Set(["pass", "warning", "fail", "not_evaluated"]);
var applications = /* @__PURE__ */ new Set(["applicable", "not_applicable", "unknown"]);
var confidences = /* @__PURE__ */ new Set(["high", "medium", "low"]);
var roundHalfUp = (n) => Math.floor(n + 0.5);
function validateWeights(weights) {
  const keys = Object.keys(weights).sort();
  const expected = [...categories].sort();
  if (keys.length !== expected.length || keys.some((key, i) => key !== expected[i])) throw new Error("Weights must contain exactly one key for every category.");
  if (Object.values(weights).some((v) => !Number.isFinite(v) || v < 0 || v > 100) || Object.values(weights).every((v) => v === 0)) throw new Error("Weights must be finite, within 0..100 percent, and have a positive total.");
  return { ...weights };
}
function score(findings, weights = DEFAULT_WEIGHTS) {
  const configured = validateWeights(weights);
  if (findings.length !== ruleIds.length) throw new Error(`Findings must contain exactly ${ruleIds.length} catalogue rules.`);
  const ids = /* @__PURE__ */ new Set();
  for (const f of findings) {
    if (!ruleIds.includes(f.ruleId)) throw new Error(`Unknown rule ID: ${f.ruleId}`);
    if (ids.has(f.ruleId)) throw new Error(`Duplicate rule ID: ${f.ruleId}`);
    ids.add(f.ruleId);
    if (!categories.includes(f.category)) throw new Error(`Unknown category: ${f.category}`);
    if (!statuses.has(f.status) || !applications.has(f.applicability) || !confidences.has(f.confidence)) throw new Error(`Invalid finding configuration: ${f.ruleId}`);
    if (!Number.isFinite(f.weight) || f.weight < 0) throw new Error(`Invalid rule weight: ${f.ruleId}`);
  }
  if (ids.size !== ruleIds.length) throw new Error("Findings are missing catalogue rule IDs.");
  const out = {};
  for (const category of categories) {
    const fs = findings.filter((f) => f.category === category && !f.advisory && !["GEO-05", "PERF-04"].includes(f.ruleId));
    let candidateWeight = 0, evaluatedWeight = 0, unknownWeight = 0, notApplicableWeight = 0, earned = 0, evaluatedCount = 0;
    for (const f of fs) {
      if (f.applicability === "not_applicable") {
        notApplicableWeight += f.weight;
        continue;
      }
      candidateWeight += f.weight;
      const eligible = f.applicability === "applicable" && f.status !== "not_evaluated" && f.confidence !== "low" && (f.status === "pass" || f.status === "warning" || f.status === "fail");
      if (!eligible) {
        unknownWeight += f.weight;
        continue;
      }
      evaluatedWeight += f.weight;
      evaluatedCount++;
      earned += f.weight * FACTOR[f.status];
    }
    const coverage = candidateWeight > 0 ? evaluatedWeight / candidateWeight : null;
    const raw = evaluatedWeight > 0 ? 100 * earned / evaluatedWeight : null;
    const gated = raw !== null && evaluatedCount >= MIN_RULES && coverage !== null && coverage >= MIN_COVERAGE;
    out[category] = { score: gated ? roundHalfUp(raw) : null, raw, coverage, candidateWeight, evaluatedWeight, unknownWeight, notApplicableWeight, evaluatedCount };
  }
  const available = categories.filter((c) => out[c].score !== null && configured[c] > 0);
  const required = out.seo.score !== null && out.structured.score !== null && (out.geo.score !== null || out.conversion.score !== null);
  const totalConfigured = available.reduce((sum, c) => sum + configured[c], 0);
  const overallRaw = required && totalConfigured > 0 ? available.reduce((sum, c) => sum + out[c].raw * configured[c], 0) / totalConfigured : null;
  const overallScore = overallRaw === null ? null : roundHalfUp(overallRaw);
  const effectiveWeights = {};
  if (totalConfigured > 0) for (const c of available) effectiveWeights[c] = configured[c] * 100 / totalConfigured;
  return { categories: out, overallScore, effectiveWeights };
}
var defaultWeights = { ...DEFAULT_WEIGHTS };

// src/extractors/index.ts
function extractPage() {
  const MAX_BYTES = 1024 * 1024, MAX_BLOCKS = 100, MAX_VISITS = 2e3, MAX_DEPTH = 20, MAX_OFFERS = 128;
  const root = document, started = performance.now();
  const limitations = [], incomplete = [];
  const budget = () => {
    if (performance.now() - started > 5e3) throw Error("EXTRACTION_TIMEOUT");
  };
  const clean = (value, max = 500) => String(value ?? "").replace(/\s+/g, " ").trim().slice(0, max);
  const redact = (value) => value.replace(/[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}/g, "[redacted-email]").replace(/\b(?:token|secret|api[_ -]?key|password|auth)[=: ]+[^\s,;]+/gi, "[redacted]");
  const privateSelector = 'input,textarea,select,script,style,template,meta,link,[data-personal],[class*="account" i],[class*="review" i],[class*="testimonial" i],[id*="account" i],[id*="review" i],.product-item,[class*="product-card" i],[class*="product-thumbnail" i],[class*="related-products" i],[class*="complementary-product" i],[class*="recommend" i],[class*="cross-sell" i],[class*="upsell" i]';
  function unrelatedForm(el) {
    const form = el.closest("form");
    if (!form) return false;
    const action = form.getAttribute("action");
    let endpoint = "";
    if (action) {
      try {
        endpoint = new URL(action, location.href).pathname;
      } catch {
      }
    }
    return /enquir|inquir|contact|newsletter|subscribe|search|login|register|review|question|notify/i.test(`${form.id} ${form.className} ${endpoint}`);
  }
  function safePlace(value) {
    const label = redact(clean(value, 80));
    return /\[redacted|https?:|@|\d{4,}|\b(?:postcode|address|customer|account|your order|zip code)\b|\b\d+\s+\w+\s+(?:street|road|avenue|lane|drive|st|rd)\b/i.test(label) ? "" : label;
  }
  function hidden(el, disclosure2) {
    if (unrelatedForm(el)) return true;
    for (let node = el; node; node = node.parentElement) {
      if (node.matches(privateSelector)) return true;
      if (!disclosure2?.contains(node)) {
        if (node.hasAttribute("hidden") || node.getAttribute("aria-hidden") === "true") return true;
        const style = getComputedStyle(node);
        if (style.display === "none" || style.visibility === "hidden") return true;
      }
    }
    return false;
  }
  function text2(el, max = 500, disclosure2) {
    if (!el || hidden(el, disclosure2)) return "";
    const walker = root.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    let node, result = "", visits2 = 0;
    while (node = walker.nextNode()) {
      if (++visits2 > 1e3) {
        if (!incomplete.includes("DOM selection limit")) incomplete.push("DOM selection limit");
        break;
      }
      if (node.parentElement && !hidden(node.parentElement, disclosure2)) result += " " + node.textContent;
      if (result.length >= max * 3) break;
    }
    return redact(clean(result, max));
  }
  const attr = (el, name2) => el && !hidden(el) ? redact(clean(el.getAttribute(name2), 300)) : "";
  function all(selector, scope = root) {
    budget();
    const nodes2 = scope.querySelectorAll(selector);
    if (nodes2.length > 250 && !incomplete.includes("DOM selection limit")) incomplete.push("DOM selection limit");
    return Array.from(nodes2).slice(0, 250).filter((el) => !hidden(el) && !unrelatedForm(el));
  }
  function first(selectors, scope = root) {
    for (const s of selectors) {
      const found = all(s, scope)[0];
      if (found) return found;
    }
    return null;
  }
  const normalized = (s) => s.normalize("NFKC").toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim();
  const language = (root.documentElement.lang || root.querySelector('meta[http-equiv="content-language"]')?.getAttribute("content") || "unknown").toLowerCase();
  const url = location.href, origin = location.origin;
  const marketplace = !!root.querySelector("#ppd #productTitle");
  const nameElement = first(["#ppd #productTitle", 'main [data-testid*="product-title" i]', "main .product-title", "main .product-name", "main h1", '[role="main"] h1', "h1"]);
  const name = text2(nameElement, 300);
  const primary = nameElement?.closest('#ppd,.product-info-main,.product__info-container,.product__info-wrapper,.c-product-main__form,.summary.entry-summary,[data-product-info],form[action*="/cart/add"]') ?? first(["main[data-product]", "main [data-product]", 'main[itemtype*="Product" i]', 'main [itemtype*="Product" i]', "main .product-info", "main .product-details"]) ?? root.querySelector('main,[role="main"]');
  const h1 = all("h1").slice(0, 20).map((el) => text2(el, 300)).filter(Boolean);
  const headingLevels = all("h1,h2,h3,h4,h5,h6").slice(0, 200).map((el) => Number(el.tagName.slice(1)));
  const metaDescription = redact(clean(root.querySelector('meta[name="description"]')?.getAttribute("content")));
  const canonicalLinks = Array.from(root.querySelectorAll('link[rel="canonical"]')).slice(0, 20).map((el) => el.getAttribute("href") ?? "").filter(Boolean);
  const canonical = { count: canonicalLinks.length, valid: canonicalLinks.length === 1 && (() => {
    try {
      return /^https?:$/.test(new URL(canonicalLinks[0], url).protocol);
    } catch {
      return false;
    }
  })() };
  const robots = Array.from(root.querySelectorAll('meta[name="robots"],meta[name="googlebot"]')).slice(0, 20).map((el) => redact(clean(el.getAttribute("content")))).filter(Boolean);
  let bytes = 0, parseErrors = 0, truncated = false;
  const blocks = [];
  const scripts = root.querySelectorAll('script[type="application/ld+json"]');
  if (scripts.length > MAX_BLOCKS) {
    truncated = true;
    limitations.push("JSON-LD block limit reached");
  }
  for (const script of Array.from(scripts).slice(0, MAX_BLOCKS)) {
    const raw = script.textContent ?? "";
    const size = new TextEncoder().encode(raw).byteLength;
    if (bytes + size > MAX_BYTES) {
      truncated = true;
      limitations.push("JSON-LD byte limit reached");
      break;
    }
    bytes += size;
    budget();
    try {
      blocks.push(JSON.parse(raw));
    } catch {
      parseErrors++;
    }
  }
  const nodes = [], refs = /* @__PURE__ */ new Map(), seen = /* @__PURE__ */ new Set();
  let visits = 0;
  const skipped = /* @__PURE__ */ new Set(["@context", "review", "aggregateRating", "shippingDetails", "hasMerchantReturnPolicy", "potentialAction", "sameAs"]);
  function visit(value, depth) {
    budget();
    if (depth > MAX_DEPTH || visits >= MAX_VISITS) {
      truncated = true;
      return;
    }
    visits++;
    if (!value || typeof value !== "object" || seen.has(value)) return;
    seen.add(value);
    if (Array.isArray(value)) {
      for (const item of value) {
        if (visits >= MAX_VISITS) {
          truncated = true;
          break;
        }
        visit(item, depth + 1);
      }
      return;
    }
    const r = value;
    if (typeof r["@id"] === "string" && (r["@type"] || Object.keys(r).length > 1) && (r["@type"] || !refs.has(r["@id"]))) refs.set(r["@id"], r);
    if (r["@type"]) nodes.push(r);
    for (const [key, child] of Object.entries(r)) {
      if (skipped.has(key)) continue;
      if (visits >= MAX_VISITS) {
        truncated = true;
        break;
      }
      visit(child, depth + 1);
    }
  }
  for (const block of blocks) visit(block, 0);
  function resolve(value) {
    if (value && typeof value === "object" && !Array.isArray(value) && typeof value["@id"] === "string") return refs.get(value["@id"]) ?? value;
    return value;
  }
  const scalar = (v) => typeof v === "string" || typeof v === "number" ? redact(clean(String(v).replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, " ").replace(/<[^>]*>/g, " "))) : "";
  function field(r, key) {
    const v = resolve(r[key]);
    return v && typeof v === "object" && !Array.isArray(v) ? scalar(v.name ?? v.value) : scalar(v);
  }
  function types(r) {
    const t = r["@type"];
    return (Array.isArray(t) ? t : [t]).filter((v) => typeof v === "string").map((v) => String(v).split("/").pop().toLowerCase());
  }
  function methodStrings(value) {
    return (Array.isArray(value) ? value : [value]).flatMap((v) => typeof v === "string" ? [v] : v && typeof v === "object" && typeof v["@id"] === "string" ? [v["@id"]] : []);
  }
  function fulfilment(methods, place) {
    const classified = methods.map((v) => {
      if (/^https?:\/\/schema\.org\/OnSitePickup$/.test(v) || /^https?:\/\/purl\.org\/goodrelations\/v1#DeliveryModePickUp$/.test(v)) return "pickup";
      if (/^https?:\/\/schema\.org\/ParcelService$/.test(v) || /^https?:\/\/purl\.org\/goodrelations\/v1#(?:DeliveryModeMail|DeliveryModeFreight|DeliveryModeOwnFleet|DHL|UPS|FederalExpress)$/.test(v)) return "delivery";
      return "unspecified";
    });
    const channels = new Set(classified);
    return { channel: classified.length && channels.size === 1 && !channels.has("unspecified") ? classified[0] : "unspecified", location: safePlace(place) || void 0 };
  }
  function offers(r) {
    const v = resolve(r.offers);
    const list = Array.isArray(v) ? v : [v];
    if (list.length > MAX_OFFERS) truncated = true;
    return list.slice(0, MAX_OFFERS).map(resolve).filter((v2) => !!v2 && typeof v2 === "object" && !Array.isArray(v2)).map((o) => ({ source: "jsonld", ...fulfilment(methodStrings(o.availableDeliveryMethod), field(o, "availableAtOrFrom")), type: types(o).includes("aggregateoffer") ? "AggregateOffer" : "Offer", price: field(o, "price"), currency: field(o, "priceCurrency"), availability: field(o, "availability"), lowPrice: field(o, "lowPrice") || void 0, highPrice: field(o, "highPrice") || void 0 }));
  }
  const skuElement = first(['[itemprop="sku"]', "[data-product-sku]", "[data-sku]"], primary ?? root);
  const sku = text2(skuElement, 100) || attr(skuElement, "data-sku") || attr(skuElement, "data-product-sku");
  const records = nodes.filter((r) => types(r).includes("product"));
  const candidates = records.map((r, i) => {
    const productName = field(r, "name"), productSku = field(r, "sku"), identifier = scalar(r["@id"]), productUrl = field(r, "url") || (/\?/.test(identifier) ? identifier : "");
    let urlMatch = false;
    if (productUrl) {
      try {
        const a = new URL(productUrl, url), b = new URL(url);
        a.hash = "";
        b.hash = "";
        urlMatch = a.href === b.href;
      } catch {
      }
    }
    return { id: `product-${i + 1}`, source: "jsonld", name: productName, description: field(r, "description"), image: !!resolve(r.image), brand: field(r, "brand"), sku: productSku, matched: !!(productName && name && normalized(productName) === normalized(name) || productSku && sku && normalized(productSku) === normalized(sku) || urlMatch), offers: offers(r) };
  });
  const matches = candidates.filter((p) => p.matched), selected = matches.length === 1 ? candidates.indexOf(matches[0]) : null;
  const ambiguous = matches.length > 1 || candidates.length > 1 && matches.length === 0;
  if (ambiguous) limitations.push("Current structured Product identity is unresolved among multiple candidates; page-level checks can still run when product context is established");
  const groupProducts = nodes.filter((r) => types(r).includes("productgroup")).map((r, i) => {
    const raw = resolve(r.hasVariant), members = (Array.isArray(raw) ? raw : [raw]).map(resolve).filter((v) => !!v && typeof v === "object" && !Array.isArray(v) && types(v).includes("product"));
    if (members.length > MAX_OFFERS) truncated = true;
    const own = offers(r), memberOffers = members.slice(0, MAX_OFFERS).flatMap(offers), captured = own.length ? own : memberOffers;
    if (captured.length > MAX_OFFERS) truncated = true;
    let urlMatch = false;
    const identity = field(r, "url") || scalar(r["@id"]);
    if (identity) {
      try {
        const a = new URL(identity, url), b = new URL(url);
        a.hash = "";
        b.hash = "";
        a.searchParams.delete("variant");
        b.searchParams.delete("variant");
        urlMatch = a.href === b.href;
      } catch {
      }
    }
    const groupName = field(r, "name");
    return { id: `group-${i + 1}`, kind: "group", source: "jsonld", name: groupName, description: field(r, "description"), image: !!resolve(r.image), brand: field(r, "brand"), sku: field(r, "productGroupID"), matched: urlMatch || !!groupName && normalized(groupName) === normalized(name), offers: captured.slice(0, MAX_OFFERS), variantCount: members.length };
  });
  const groupMatches = groupProducts.filter((p) => p.matched);
  const groups = { products: groupProducts, selected: groupMatches.length === 1 ? groupProducts.indexOf(groupMatches[0]) : null, ambiguous: groupMatches.length > 1 || groupProducts.length > 1 && groupMatches.length === 0 };
  if (groups.selected !== null) limitations.push("ProductGroup family recognised; family offers are not a confirmed selected variant.");
  const microLimits = [];
  let microTruncated = false;
  const machinePrivate = 'input,textarea,select,script,style,template,[data-personal],[class*="account" i],[class*="review" i],[id*="review" i],.product-item,[class*="product-card" i],[class*="product-thumbnail" i],[class*="related-products" i],[class*="complementary-product" i],[class*="recommend" i],[class*="cross-sell" i],[class*="upsell" i]';
  const safeMachine = (el) => !el.closest(machinePrivate) && !unrelatedForm(el);
  const microTypes = (el) => (el.getAttribute("itemtype") ?? "").split(/\s+/).map((v) => v.match(/^https?:\/\/schema\.org\/(\w+)$/)?.[1] ?? "");
  function ownProperties(scope, key) {
    budget();
    const props = scope.querySelectorAll(`[itemprop~="${key}"]`);
    const owned = [];
    if (props.length > 2e3) microTruncated = true;
    for (const el of Array.from(props).slice(0, 2e3)) {
      if (!safeMachine(el) || (el.hasAttribute("itemscope") ? el.parentElement?.closest("[itemscope]") : el.closest("[itemscope]")) !== scope) continue;
      if (owned.length >= 250) {
        microTruncated = true;
        break;
      }
      owned.push(el);
    }
    return owned;
  }
  function microValue(el, scope) {
    if (!safeMachine(el)) return "";
    if (el.tagName === "META") return scalar(el.getAttribute("content"));
    if (["LINK", "A", "AREA"].includes(el.tagName)) return scalar(el.getAttribute("href"));
    if (["IMG", "SOURCE", "VIDEO", "AUDIO"].includes(el.tagName)) return scalar(el.getAttribute("src"));
    if (el.tagName === "TIME") return scalar(el.getAttribute("datetime"));
    return text2(el, 500, scope);
  }
  function microField(scope, key) {
    const values = ownProperties(scope, key).map((el) => microValue(el, scope)).filter(Boolean);
    if (["name", "sku", "price", "priceCurrency", "availability", "lowPrice", "highPrice"].includes(key) && new Set(values).size > 1) {
      microTruncated = true;
      microLimits.push(`Conflicting microdata ${key} values are not uniquely interpreted`);
      return "";
    }
    return values[0] ?? "";
  }
  const typedScopes = root.querySelectorAll("[itemscope][itemtype]");
  if (typedScopes.length > 2e3) microTruncated = true;
  const productRoots = Array.from(typedScopes).slice(0, 2e3).filter((el) => microTypes(el).includes("Product") && safeMachine(el));
  if (Array.from(typedScopes).slice(0, 2e3).some((el) => microTypes(el).includes("ProductGroup")) || root.querySelector('[typeof~="Product"],[typeof~="ProductGroup"],[typeof~="schema:Product"],[typeof~="schema:ProductGroup"],[typeof~="https://schema.org/Product"],[typeof~="https://schema.org/ProductGroup"]')) incomplete.push("Unsupported product structured-data format detected (ProductGroup microdata or RDFa); absence is not established");
  if (productRoots.length > 20) {
    microTruncated = true;
    microLimits.push("Microdata Product candidate limit reached");
  }
  const microProducts = productRoots.slice(0, 20).map((scope, index) => {
    if (scope.hasAttribute("itemref")) {
      microTruncated = true;
      microLimits.push("Microdata itemref is outside the supported subset");
    }
    const productName = microField(scope, "name"), productSku = microField(scope, "sku");
    const brandScope = ownProperties(scope, "brand")[0];
    const productBrand = brandScope?.hasAttribute("itemscope") ? microField(brandScope, "name") : brandScope ? microValue(brandScope, scope) : "";
    const offerRoots = ownProperties(scope, "offers").filter((el) => el.hasAttribute("itemscope") && microTypes(el).some((t) => t === "Offer" || t === "AggregateOffer"));
    if (offerRoots.length > MAX_OFFERS) microTruncated = true;
    const productOffers = offerRoots.slice(0, MAX_OFFERS).map((offer) => {
      if (offer.hasAttribute("itemref")) {
        microTruncated = true;
        microLimits.push("Microdata Offer itemref is outside the supported subset");
      }
      const places = ownProperties(offer, "availableAtOrFrom");
      const place = places.length === 1 ? places[0].hasAttribute("itemscope") ? microField(places[0], "name") : microValue(places[0], offer) : "";
      const methods = ownProperties(offer, "availableDeliveryMethod").map((el) => microValue(el, offer));
      return { source: "microdata", ...fulfilment(methods, place), type: microTypes(offer).includes("AggregateOffer") ? "AggregateOffer" : "Offer", price: microField(offer, "price"), currency: microField(offer, "priceCurrency"), availability: microField(offer, "availability"), lowPrice: microField(offer, "lowPrice") || void 0, highPrice: microField(offer, "highPrice") || void 0 };
    });
    const headingScope = !!nameElement && scope.contains(nameElement) && (!productName || normalized(productName) === normalized(name));
    const matched = !!(productName && name && normalized(productName) === normalized(name) || productSku && sku && normalized(productSku) === normalized(sku) || headingScope);
    return { id: `microdata-product-${index + 1}`, source: "microdata", name: productName, description: microField(scope, "description"), image: !!microField(scope, "image"), brand: productBrand, sku: productSku, matched, offers: productOffers };
  });
  const microMatches = microProducts.filter((p) => p.matched);
  const microdata = { products: microProducts, selected: microMatches.length === 1 ? microProducts.indexOf(microMatches[0]) : null, ambiguous: microMatches.length > 1 || microProducts.length > 1 && microMatches.length === 0, truncated: microTruncated, limitations: Array.from(new Set(microLimits)) };
  if (microProducts.length) limitations.push("Product/Offer microdata subset inspected separately; not full microdata or rich-result eligibility validation.", ...microdata.limitations);
  const detailSelectors = ["#productDescription", 'main [id="product.info.description"]', "main .product.attribute.description .value", 'main [data-testid*="description" i]', "main .product-description", "main .product__description", 'main [class*="product-main__description"]', 'main [itemprop="description"]', "main .description"];
  let descriptionElement = first(detailSelectors), descriptionSource = "visible", disclosure;
  if (!descriptionElement) {
    const controls2 = Array.from(root.querySelectorAll('[aria-controls],a[href^="#"]')).slice(0, 250).filter((e) => !hidden(e));
    for (const selector of detailSelectors) {
      for (const el of Array.from(root.querySelectorAll(selector)).slice(0, 20)) {
        const panel = el.closest('[role="tabpanel"],[id]');
        if (!panel?.id) continue;
        if (controls2.some((c) => (c.getAttribute("aria-controls") ?? "").split(/\s+/).includes(panel.id) || c.getAttribute("href") === `#${panel.id}`)) {
          descriptionElement = el;
          disclosure = panel;
          descriptionSource = "expandable";
          break;
        }
      }
      if (descriptionElement) break;
    }
  }
  let description = descriptionElement?.querySelector("template") ? all("p,.rte,[data-product-description]", descriptionElement).filter((el) => !el.closest('label,button,[role="tab"]')).map((el) => text2(el, 1200, disclosure)).join(" ").slice(0, 1200) : text2(descriptionElement, 1200, disclosure);
  if (!description && primary) {
    const identityWords = normalized(name).split(" ").filter((w) => w.length >= 4);
    const paragraph = all("p", primary).find((el) => !el.closest('[class*="price" i],[class*="pricing" i],[class*="payment" i],[class*="shipping" i],[class*="return" i],[class*="installment" i],[class*="quantity" i]') && text2(el, 1e3).length >= 80 && identityWords.some((w) => normalized(text2(el, 1e3)).split(" ").includes(w)));
    description = text2(paragraph ?? null, 1200);
  }
  if (!description) descriptionSource = "unknown";
  if (descriptionSource === "expandable") limitations.push("Product description is in an explicitly linked expandable panel; not initially visible.");
  const tables = [...all("main #product-attribute-specs-table,main .additional-attributes,main [data-product-specifications]"), ...primary ? all('table,dl,[itemprop="additionalProperty"],[class*="specification" i]', primary) : []];
  const specifications = Array.from(new Set(tables)).slice(0, 20).map((el) => text2(el, 250)).filter(Boolean);
  let brand = text2(first(['[itemprop="brand"]', "[data-brand]"], primary ?? root), 200);
  if (!brand) {
    for (const table of tables) {
      const cell = table.querySelector('td[data-th="Brand" i]');
      if (cell) {
        brand = text2(cell, 200);
        break;
      }
      const row = Array.from(table.querySelectorAll("tr")).find((r) => /^brand$/i.test(text2(r.querySelector("th,td"), 80)));
      if (row) {
        brand = text2(row.querySelectorAll("th,td")[1] ?? null, 200);
        break;
      }
    }
  }
  const category = all('nav[aria-label*="breadcrumb" i],.breadcrumbs,.breadcrumb,main [data-category]').map((el) => text2(el, 300)).filter((v) => {
    const remaining = normalized(v).replace(/^home\s*/, "").replace(normalized(name), "").trim();
    return !!remaining;
  }).join(" | ").slice(0, 500);
  const context = all('main [class*="shipping" i],main [class*="return" i],main [class*="policy" i],main [class*="benefit" i],main [class*="faq" i]').slice(0, 20).map((el) => text2(el, 250)).filter(Boolean);
  const policyLinks = all('a[href*="shipping" i],a[href*="delivery" i],a[href*="returns" i],a[href*="refund" i]');
  let shipping = context.some((v) => /\bship|delivery|versand/i.test(v)), returns = context.some((v) => /\breturn|refund|retour/i.test(v));
  for (const link of policyLinks) {
    const href = link.getAttribute("href") ?? "", label = text2(link, 100);
    if (!label) continue;
    if (/shipping|delivery/i.test(href)) {
      shipping = true;
      context.push(`Delivery information link: ${label}`);
    }
    if (/returns|refund/i.test(href)) {
      returns = true;
      context.push(`Returns information link: ${label}`);
    }
  }
  const marketPrices = marketplace ? all("#corePriceDisplay_desktop_feature_div .priceToPay,#corePrice_feature_div .priceToPay,#apex_desktop .priceToPay") : [];
  const marketPrice = marketPrices.length === 1 ? marketPrices[0] : null;
  const priceNodes = marketplace ? marketPrice ? [marketPrice] : [] : primary ? all('[data-price],[data-product-price],.price,.product-price,.price-box,[itemprop="price"],.c-product-main__pricing-price,.product__price .money,.price__regular .price-item', primary) : [];
  const priceLeaves = priceNodes.filter((el) => !priceNodes.some((other) => other !== el && el.contains(other)));
  const priceTexts = priceLeaves.map((el) => text2(el, 180)).filter(Boolean);
  if (marketPrice && !priceTexts.length) {
    const whole = marketPrice.querySelector(".a-price-whole"), fraction = marketPrice.querySelector(".a-price-fraction");
    const painted = (el) => {
      for (let n = el; n && n !== marketPrice; n = n.parentElement) {
        const style = getComputedStyle(n);
        if (n.hasAttribute("hidden") || style.display === "none" || style.visibility === "hidden") return false;
      }
      return true;
    };
    if (whole?.tagName === "SPAN" && fraction?.tagName === "SPAN" && marketPrice.querySelectorAll(".a-price-whole").length === 1 && marketPrice.querySelectorAll(".a-price-fraction").length === 1 && painted(whole) && painted(fraction)) {
      const a = clean(whole.textContent, 60).replace(/\s+/g, "").replace(/[.,]$/, ""), b = clean(fraction.textContent, 8);
      const separator = language.startsWith("en") ? "." : /^(de|fr|es|it|pt|nl)/.test(language) ? "," : "";
      if (separator && /^[\d.,]+$/.test(a) && /^\d{1,3}$/.test(b)) priceTexts.push(a + separator + b);
    }
  }
  const priceContext = priceLeaves.map((el) => text2(el.closest(".price-box,.price-container,[data-price-container],.o-pricing") ?? el, 250)).join(" | ");
  const codes = Intl.supportedValuesOf("currency");
  const currencyCode = (v) => (v.match(/\b[A-Z]{3}\b/g) ?? []).find((c) => codes.includes(c)) ?? "";
  const currencyCandidates = priceLeaves.flatMap((el) => [text2(el, 180), attr(el, "data-currency"), attr(el, "aria-label"), ...all('[data-currency],[itemprop="priceCurrency"]', el).map((c) => text2(c, 50) || attr(c, "data-currency"))]).map(currencyCode).filter(Boolean);
  const distinctCurrencies = Array.from(new Set(currencyCandidates));
  let currency2 = distinctCurrencies.length === 1 ? distinctCurrencies[0] : "";
  let currencySource = currency2 ? "visible" : "unknown";
  if (!currency2 && distinctCurrencies.length === 0) {
    const metadata = Array.from(root.querySelectorAll('meta[property="product:price:currency"],meta[property="og:price:currency"]')).map((el) => currencyCode(el.getAttribute("content") ?? "")).filter(Boolean);
    if (new Set(metadata).size === 1) {
      currency2 = metadata[0];
      currencySource = "metadata";
    }
  }
  function normalizeMoney(raw) {
    const s = raw.trim().replace(/[\s\u00a0\u202f]/g, "");
    if (language.startsWith("en")) return /^(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d{1,6})?$/.test(s) ? s.replace(/,/g, "") : null;
    if (/^(de|fr|es|it|pt|nl)/.test(language)) return /^(?:\d+|\d{1,3}(?:\.\d{3})+)(?:,\d{1,6})?$/.test(s) ? s.replace(/\./g, "").replace(",", ".") : null;
    return /^\d+$/.test(s) ? s : null;
  }
  const numbers = priceTexts.flatMap((v) => v.match(/\d[\d.,\u00a0\u202f ]*/g) ?? []), normalizedPrices = numbers.map(normalizeMoney);
  const unique = Array.from(new Set(normalizedPrices.map((v, i) => v ?? numbers[i].trim())));
  const from = /\bfrom\b|\bstarting\b/i.test(priceContext), range = /\d[\d.,]*\s*[-–]\s*\d/.test(priceContext);
  const ambiguousPrice = /\b(?:was|installment|per month|monthly|list|msrp)\b/i.test(priceContext) || unique.length > 1;
  const priceKind = from ? "from" : range ? "range" : unique.length === 1 && !ambiguousPrice ? "exact" : "unknown";
  const price = unique.length === 1 ? unique[0] : range ? unique.slice(0, 2).join(" \u2013 ") : "";
  const optionRoot = marketplace ? root.querySelector("#twister_feature_div,#twister") : primary;
  const controls = optionRoot ? Array.from(optionRoot.querySelectorAll('select,[role="radio"],input[type="radio"]:not([name*="quantity" i])')).slice(0, 100).filter((el) => !el.closest('product-description,.product-description,[role="tablist"],[class*="size-guide" i],[id*="size-guide" i]') && !/quantity|^qty$/i.test(`${el.id} ${el.getAttribute("name") ?? ""}`) && el.parentElement && !hidden(el.parentElement) && !unrelatedForm(el) && !el.hasAttribute("hidden") && getComputedStyle(el).display !== "none" && getComputedStyle(el).visibility !== "hidden") : [];
  const variants = controls.length;
  const variantsLabelled = variants > 0 && controls.every((el) => !!clean(el.getAttribute("aria-label")) || (el.getAttribute("aria-labelledby") ?? "").split(/\s+/).filter(Boolean).some((id) => !!text2(root.getElementById(id), 100)) || !!el.id && Array.from(root.querySelectorAll("label")).some((l) => l.getAttribute("for") === el.id && !!text2(l, 100)) || !!text2(el.closest("label"), 100));
  const cartButtons = primary ? all('button,[role="button"]', primary).filter((el) => /add\s*to\s*(?:cart|bag|basket)|buy\s*now|purchase|加入购物车|acheter/i.test(text2(el, 100) || attr(el, "aria-label"))) : [];
  if (marketplace && primary) cartButtons.push(...Array.from(primary.querySelectorAll('input[type="submit"]#add-to-cart-button,input[type="submit"]#buy-now-button,input[type="submit"][name="submit.add-to-cart"]')).filter((el) => el.parentElement && !hidden(el.parentElement) && !unrelatedForm(el) && !el.hasAttribute("hidden") && getComputedStyle(el).display !== "none" && getComputedStyle(el).visibility !== "hidden"));
  const cart = cartButtons.length > 0, cartEnabled = cartButtons.some((el) => !el.disabled && el.getAttribute("aria-disabled") !== "true");
  function visibleStockState(value) {
    const v = clean(value, 120).replace(/^(?:stock|availability)\s*:\s*/i, "").trim();
    const negative = /\b(?:out[ -]?of[ -]?stock|sold[ -]?out|unavailable|not available|not in stock)\b/i.test(v);
    const withoutNegative = v.replace(/out[ -]?of[ -]?stock|not in stock|not available|unavailable|sold[ -]?out/gi, "").replace(/available\s+(?:on|for)\s+(?:back[ -]?order|pre[ -]?order)/gi, "");
    const positive = /\b(?:in[ -]?stock|low[ -]?stock|limited stock|available)\b/i.test(withoutNegative);
    const future = /\b(?:back[ -]?order|pre[ -]?order)\b/i.test(v);
    if (positive && (negative || future) || negative && future) return "unknown";
    if (/^(?:out[ -]?of[ -]?stock|sold[ -]?out|unavailable|not available|not in stock)(?:\s*[.!].*)?$/i.test(v)) return "out_of_stock";
    if (/^(?:(?:available\s+(?:on|for)\s+)?back[ -]?order(?:ed)?|on order)(?:\s*[.!].*)?$/i.test(v)) return "backorder";
    if (/^(?:available\s+for\s+)?pre[ -]?order(?:\s*[.!].*)?$/i.test(v)) return "preorder";
    const remaining = v.match(/^only\s+(\d{1,6})\s+(?:left|remaining)(?:\s*[.!].*)?$/i);
    if (remaining) return Number(remaining[1]) === 0 ? "out_of_stock" : "low_stock";
    const quantity = v.match(/^(\d{1,6})\s+in[ -]?stock(?:\s*[.!].*)?$/i);
    if (quantity) return Number(quantity[1]) === 0 ? "out_of_stock" : "in_stock";
    if (/^(?:low[ -]?stock|limited[ -]?(?:stock|availability))(?:\s*[.!].*)?$/i.test(v)) return "low_stock";
    if (/^(?:in[ -]?stock|available)(?:\s*[.!].*)?$/i.test(v)) return "in_stock";
    return void 0;
  }
  const stockNodes = [];
  let stockTruncated = false;
  const stockRoot = marketplace ? root.querySelector("#desktop_buybox,#buybox") ?? primary : primary;
  if (stockRoot) {
    const walker = root.createTreeWalker(stockRoot, NodeFilter.SHOW_ELEMENT, { acceptNode: (node2) => hidden(node2) || unrelatedForm(node2) || node2.closest('[role="tooltip"],.tooltip,.variant-picker__status,[data-stock-legend],[class*="size-legend" i],[class*="availability-key" i]') ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT });
    let node, scanned = 0;
    while (node = walker.nextNode()) {
      budget();
      if (++scanned > 4e3) {
        stockTruncated = true;
        break;
      }
      const el = node;
      if (el.children.length && !Array.from(el.childNodes).some((n) => n.nodeType === Node.TEXT_NODE && !!clean(n.textContent))) continue;
      const rawText = text2(el, 121);
      if (rawText.length > 120) continue;
      const status = visibleStockState(rawText);
      if (!status) continue;
      if (stockNodes.length >= 24) {
        stockTruncated = true;
        break;
      }
      stockNodes.push({ el, status, rawText });
    }
  }
  function stockContext(el, rawText) {
    if (marketplace && el.closest("#availability")) return { channel: "unspecified", contextLabel: "Current buy box" };
    let label = "", unresolved = false;
    let channel = "unspecified";
    for (let ancestor = el.parentElement, depth = 0; ancestor && ancestor !== primary && depth < 4; ancestor = ancestor.parentElement, depth++) {
      if (stockNodes.filter((n) => ancestor.contains(n.el)).length !== 1) break;
      if (ancestor.querySelector('input[autocomplete*="address" i],input[name*="postcode" i],input[name*="address" i],input[name*="zip" i]')) {
        unresolved = true;
        break;
      }
      if (nameElement && ancestor.contains(nameElement) || cartButtons.some((b) => ancestor.contains(b)) || ancestor.querySelector("input,textarea,select")) break;
      const raw = text2(ancestor, 240);
      if (raw.length > 180) continue;
      const rawLabel = raw.replace(rawText, "").replace(/^[\s:|–-]+|[\s:|–-]+$/g, "");
      const candidate = safePlace(rawLabel);
      if (rawLabel && !candidate) unresolved = true;
      if (candidate && candidate.length <= 80 && candidate.split(" ").length <= 10 && !/\d[.,]\d|[$€£]|\b(?:stock|inventory|availability|status)\b/i.test(candidate) && normalized(candidate) !== normalized(name)) {
        label = candidate;
        break;
      }
    }
    if (/^(?:delivery|shipping)(?:\s+(?:availability|stock))?$/i.test(label)) channel = "delivery";
    else if (/^(?:pickup|pick[ -]?up|click\s*(?:&|and)\s*collect)\b|^collection(?:\s*[:–-]|$)/i.test(label)) channel = "pickup";
    if (channel === "unspecified") {
      for (let ancestor = el.parentElement, depth = 0; ancestor && depth < 6; ancestor = ancestor.parentElement, depth++) {
        if (ancestor === primary || nameElement && ancestor.contains(nameElement)) break;
        const context2 = text2(ancestor, 320);
        const pickup = /\b(?:click\s*(?:&|and)\s*collect|pick[ -]?up)\b/i.test(context2) || Array.from(ancestor.querySelectorAll("h2,h3,h4,legend")).some((h) => /^collection$/i.test(text2(h, 80))), delivery = /\b(?:delivery|shipping)\b/i.test(context2);
        if (pickup && !delivery) {
          channel = "pickup";
          break;
        }
        if (delivery && !pickup) {
          channel = "delivery";
          break;
        }
      }
    }
    const location2 = channel === "pickup" ? safePlace(label.replace(/^(?:pickup|pick[ -]?up|click\s*(?:&|and)\s*collect|collection)\s*[:–-]?\s*/i, "")) : "";
    return { channel, location: location2 || void 0, contextLabel: unresolved ? "Unresolved fulfilment context" : label };
  }
  const stockObservations = stockNodes.map(({ el, status, rawText }) => {
    const suffix = rawText.match(/[.!]\s*(\S.*)$/)?.[1];
    const qualified = !!suffix && !/^selling fast[.!]?$/i.test(suffix);
    const context2 = stockContext(el, rawText);
    return { ...context2, status, rawText, source: "visible", confidence: status === "unknown" ? "low" : qualified || context2.contextLabel === "Unresolved fulfilment context" ? "medium" : "high" };
  });
  if (stockTruncated) limitations.push("Visible stock scan reached its bound; observations may be partial.");
  const single = !stockTruncated && stockObservations.length === 1 && stockObservations[0].confidence === "high" && stockObservations[0].channel === "unspecified" && !stockObservations[0].contextLabel ? stockObservations[0] : void 0;
  const availability2 = single?.status === "in_stock" || single?.status === "low_stock" ? "in_stock" : single?.status === "out_of_stock" ? "out_of_stock" : "unknown";
  const priceReliable = priceKind === "exact" && !!price && !!currency2 && currencySource === "visible" && normalizedPrices.every((v) => v !== null) && variants === 0 && !ambiguous;
  const gallery = first(["#ppd #imgTagWrapperId", "main product-gallery", "main .product.media", 'main [data-gallery-role="gallery-placeholder"]', "main media-gallery", "main .product__media-gallery", "main .woocommerce-product-gallery", "main [data-product-gallery]", 'main [class*="product-main__gallery"]', 'main [class*="product-main__media"]', 'main [class*="product-main__images"]']);
  const galleryScope = gallery ?? primary?.closest('[data-product],[itemtype*="Product" i],.c-product-main,.product-main,.product') ?? primary ?? root.querySelector("main");
  const images = galleryScope ? Array.from(galleryScope.querySelectorAll("img")).slice(0, 100).filter((el) => !hidden(el) && !el.closest('[class*="logo" i],[class*="avatar" i]') && el.getAttribute("role") !== "presentation" && el.getAttribute("role") !== "none").slice(0, 40).map((el) => {
    const im = el, rect = im.getBoundingClientRect(), css = getComputedStyle(im);
    return { alt: attr(im, "alt") || null, width: im.width || Number(attr(im, "width")) || 0, height: im.height || Number(attr(im, "height")) || 0, naturalWidth: im.naturalWidth || 0, naturalHeight: im.naturalHeight || 0, dimensionHints: !!attr(im, "width") && !!attr(im, "height") || !!css.aspectRatio && css.aspectRatio !== "auto", lazy: im.loading === "lazy" || !!attr(im, "data-src"), offscreen: rect.top > innerHeight || rect.bottom < 0, loaded: im.complete && im.naturalWidth > 0 };
  }) : [];
  if (!description) incomplete.push("Rendered product description unavailable");
  if (!specifications.length) incomplete.push("Product specifications not identified; optional applicability unknown");
  if (!images.length) incomplete.push("Relevant product gallery images unavailable");
  if (!price) incomplete.push("Visible product price is missing or ambiguous");
  if (!records.length && !groupProducts.length && !microProducts.length) incomplete.push("Structured product data unavailable");
  if (truncated) incomplete.push("Structured-data limits may affect structured fields");
  if (root.querySelector("iframe")) limitations.push("Only the main frame was inspected; embedded frames are unsupported.");
  if (priceKind === "from" || priceKind === "range") limitations.push("A starting/range price is displayed, not a confirmed selected-variant price.");
  if (currencySource === "metadata") limitations.push("Currency comes from page metadata, not an explicit visible ISO code; price mismatches are not confirmed.");
  if (price && currencySource === "unknown") limitations.push("Price amount found, but currency is not independently identifiable; no confirmed price comparison.");
  const domProduct = !!name && !!primary && (!!priceNodes.length && cart || marketplace && (!!priceNodes.length || cart));
  const likelyProduct = selected !== null || groups.selected !== null || microdata.selected !== null || domProduct;
  const gateTitle = /^(?:access (?:to this page )?(?:has been )?(?:denied|blocked)|robot check(?:\s*[-|]|$)|just a moment[.!…]*$|attention required.*cloudflare|security verification)/i.test(clean(root.title));
  const gateFrame = !!root.querySelector('iframe[src*="_Incapsula_Resource"],iframe[src*="captcha" i],#px-captcha,#captchacharacters');
  const blocked = !domProduct && (gateTitle || gateFrame && !likelyProduct);
  if (blocked) limitations.push("Access/security verification screen detected; no product audit is possible. No challenge or login is bypassed.");
  return {
    version: "0.1",
    origin,
    language,
    classification: blocked ? "blocked" : likelyProduct ? "product" : ambiguous || microdata.ambiguous || groups.ambiguous ? "ambiguous" : "non_product",
    title: redact(clean(root.title)),
    metaDescription,
    h1,
    headingLevels,
    canonical,
    robots,
    product: { name, description, descriptionSource, brand, category, specifications, context: context.slice(0, 20), price, priceKind, currency: currency2, currencySource, priceReliable, availability: availability2, stockObservations, stockTruncated, cart, cartEnabled, variants, variantsLabelled, shipping, returns, shippable: shipping ? true : null, images },
    schema: { products: candidates, selected, parseErrors, ambiguous, truncated, microdata, groups },
    technical: { domCount: root.querySelectorAll("*").length, scripts: root.scripts.length, styles: root.querySelectorAll('link[rel="stylesheet"],style').length, dpr: devicePixelRatio || 1 },
    limitations,
    incomplete,
    unstable: false
  };
}

// src/reports/index.ts
async function makeReport(snapshot, weights) {
  const input = JSON.stringify(snapshot);
  if (input.length > 2 * 1024 * 1024) throw Error("SNAPSHOT_TOO_LARGE");
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(input));
  const findings = evaluate(snapshot), scores = score(findings, weights), evidence = productEvidence(snapshot);
  return {
    version: "0.2.0",
    ruleVersion: "0.2.0",
    configuredWeights: { ...weights ?? defaultWeights },
    id: crypto.randomUUID(),
    capturedAt: (/* @__PURE__ */ new Date()).toISOString(),
    origin: snapshot.origin,
    snapshotHash: Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join(""),
    classification: snapshot.classification,
    findings,
    ...scores,
    stockObservations: snapshot.product.stockObservations ?? [],
    structuredEvidence: { source: evidence.product ? evidence.source : "none", jsonldProducts: snapshot.schema.products.length, jsonldGroups: snapshot.schema.groups?.products.length ?? 0, subject: evidence.product ? evidence.product.kind === "group" ? "group" : "product" : "none", microdataProducts: snapshot.schema.microdata?.products.length ?? 0, subsetOnly: true },
    limitations: [...snapshot.limitations, ...snapshot.incomplete, "Visible stock is the website statement at capture time, not verified inventory or a fulfilment guarantee.", "Local technical observations \u2014 not a performance audit.", "AI Discoverability is content readiness, not rankings or citation probability.", "HTTP headers, robots.txt, lab/field performance and inaccessible frames/shadow roots are not evaluated."]
  };
}

// src/storage/index.ts
var EVENTS = ["extension_opened", "audit_started", "audit_completed", "audit_failed", "finding_expanded", "report_copied", "report_exported", "website_clicked", "consultation_clicked"];
var counterQueue = Promise.resolve();
var sessionQueue = Promise.resolve();
function mutateSession(operation) {
  const next = sessionQueue.catch(() => {
  }).then(operation);
  sessionQueue = next;
  return next;
}
function count(event) {
  counterQueue = counterQueue.catch(() => {
  }).then(async () => {
    const data = await chrome.storage.local.get("counters");
    const counters = data.counters ?? {};
    counters[event] = Math.min(1e9, (Number(counters[event]) || 0) + 1);
    await chrome.storage.local.set({ counters });
  });
  return counterQueue;
}
async function clearCounters() {
  await counterQueue;
  await chrome.storage.local.remove("counters");
}
async function readCache() {
  const data = await chrome.storage.session.get("reports");
  return data.reports ?? [];
}
function cacheReport(report, tabId, documentId, isCurrent = () => true, job) {
  return mutateSession(async () => {
    const reports = await readCache();
    if (!isCurrent()) throw Error("INTERRUPTED");
    const next = [{ report, tabId, documentId, savedAt: Date.now(), stale: false }, ...reports.filter((r) => Date.now() - r.savedAt < 30 * 6e4 && r.tabId !== tabId)].slice(0, 10);
    await chrome.storage.session.set({ reports: next, ...job ? { job } : {} });
  });
}
function cachedReport(tabId) {
  return mutateSession(async () => {
    const reports = await readCache();
    const valid = reports.filter((r) => Date.now() - r.savedAt < 30 * 6e4);
    if (valid.length !== reports.length) await chrome.storage.session.set({ reports: valid });
    return valid.find((r) => r.tabId === tabId && !r.stale)?.report ?? null;
  });
}
function markStale(tabId) {
  return mutateSession(async () => {
    const reports = await readCache();
    await chrome.storage.session.set({ reports: reports.map((r) => r.tabId === tabId ? { ...r, stale: true } : r) });
  });
}
function clearReports() {
  return mutateSession(() => chrome.storage.session.remove(["reports", "job"]));
}

// src/service-worker.ts
var activeJob = null;
var PANEL = chrome.runtime.getURL("sidepanel.html");
var errorResponse = (code) => ({ ok: false, error: code });
void chrome.storage.session.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" });
chrome.runtime.onInstalled.addListener(() => {
  activeJob = null;
  void mutateSession(() => chrome.storage.session.remove(["reports", "job", "grant"]));
});
chrome.action.onClicked.addListener((tab) => {
  if (tab.id === void 0) return;
  void chrome.sidePanel.open({ windowId: tab.windowId }).catch(() => {
  });
  const grant = { tabId: tab.id, windowId: tab.windowId, generation: crypto.randomUUID() };
  activeJob = null;
  void mutateSession(() => chrome.storage.session.set({ grant, job: null }));
});
chrome.tabs.onUpdated.addListener((tabId, change) => {
  if (change.status === "loading") void invalidate(tabId);
});
chrome.tabs.onRemoved.addListener((tabId) => {
  void invalidate(tabId);
});
async function invalidate(tabId) {
  const data = await chrome.storage.session.get(["grant", "job"]);
  const grant = data.grant;
  if (grant?.tabId === tabId) {
    activeJob = null;
    await chrome.storage.session.remove(["grant", "job"]);
  }
  await markStale(tabId);
}
async function target() {
  const { grant } = await chrome.storage.session.get("grant");
  if (!grant) throw Error("ACTION_REQUIRED");
  const tabs = await chrome.tabs.query({ active: true, windowId: grant.windowId });
  if (tabs[0]?.id !== grant.tabId) throw Error("ACTION_REQUIRED");
  const tab = await chrome.tabs.get(grant.tabId);
  if (!tab.url || !/^https?:\/\//.test(tab.url)) throw Error("UNSUPPORTED_PAGE");
  const url = new URL(tab.url);
  if (url.hostname === "chromewebstore.google.com" || url.hostname === "chrome.google.com" && url.pathname.startsWith("/webstore")) throw Error("UNSUPPORTED_PAGE");
  return grant;
}
async function assertCurrent(job) {
  if (activeJob !== job.id || Date.now() > job.deadline) throw Error("INTERRUPTED");
  const grant = await target();
  if (grant.generation !== job.generation) throw Error("ACTION_REQUIRED");
}
async function audit() {
  let job;
  try {
    const grant = await target();
    if (activeJob) throw Error("BUSY");
    job = { id: crypto.randomUUID(), tabId: grant.tabId, generation: grant.generation, phase: "extracting", startedAt: Date.now(), deadline: Date.now() + 1e4 };
    activeJob = job.id;
    await chrome.storage.session.set({ job });
    await count("audit_started");
    const result = await chrome.scripting.executeScript({ target: { tabId: grant.tabId }, func: extractPage });
    await assertCurrent(job);
    const entry = result[0];
    const snapshot = entry?.result;
    if (!snapshot || entry.frameId !== 0 || typeof entry.documentId !== "string" || JSON.stringify(snapshot).length > 2 * 1024 * 1024 || snapshot.version !== "0.1") throw Error("INVALID_SNAPSHOT");
    if (snapshot.classification === "blocked") throw Error("ACCESS_BLOCKED");
    job.documentId = entry.documentId;
    job.phase = "evaluating";
    await chrome.storage.session.set({ job });
    const settings = await chrome.storage.local.get("weights");
    const weights = settings.weights ? validateWeights(settings.weights) : defaultWeights;
    const report = await makeReport(snapshot, weights);
    await assertCurrent(job);
    job.phase = "completed";
    await cacheReport(report, job.tabId, entry.documentId, () => activeJob === job.id && Date.now() <= job.deadline, job);
    await assertCurrent(job);
    await count("audit_completed");
    await assertCurrent(job);
    return { ok: true, report };
  } catch (error) {
    const code = error instanceof Error ? error.message : "";
    const allowed = ["ACTION_REQUIRED", "UNSUPPORTED_PAGE", "BUSY", "INTERRUPTED", "INVALID_SNAPSHOT", "SNAPSHOT_TOO_LARGE", "ACCESS_BLOCKED"];
    if (job && activeJob === job.id) {
      job.phase = "failed";
      await chrome.storage.session.set({ job });
      await count("audit_failed");
    }
    return errorResponse(allowed.includes(code) ? code : "ANALYSIS_FAILED");
  } finally {
    if (job && activeJob === job.id) activeJob = null;
  }
}
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "panel" || port.sender?.id !== chrome.runtime.id || port.sender?.url !== PANEL) {
    port.disconnect();
    return;
  }
  port.onDisconnect.addListener(() => {
    if (activeJob) {
      activeJob = null;
      void chrome.storage.session.get("job").then(({ job }) => {
        if (job) return chrome.storage.session.set({ job: { ...job, phase: "interrupted" } });
      });
    }
  });
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id || sender.url !== PANEL || sender.tab || !message || typeof message !== "object") return false;
  const m = message;
  if (typeof m.type !== "string" || JSON.stringify(m).length > 1e3) {
    sendResponse(errorResponse("INVALID_MESSAGE"));
    return false;
  }
  const allowedKeys = m.type === "set_weights" ? ["type", "weights"] : ["type", "event"];
  const keys = Object.keys(m);
  if (keys.some((k) => !allowedKeys.includes(k))) {
    sendResponse(errorResponse("INVALID_MESSAGE"));
    return false;
  }
  const run = async () => {
    switch (m.type) {
      case "analyse":
        return audit();
      case "get_weights": {
        const data = await chrome.storage.local.get("weights");
        return { ok: true, weights: data.weights ?? defaultWeights };
      }
      case "set_weights": {
        try {
          if (!m.weights || typeof m.weights !== "object" || Array.isArray(m.weights)) return errorResponse("INVALID_WEIGHTS");
          const weights = validateWeights(m.weights);
          await chrome.storage.local.set({ weights });
          return { ok: true, weights };
        } catch {
          return errorResponse("INVALID_WEIGHTS");
        }
      }
      case "init": {
        const { job } = await chrome.storage.session.get("job");
        if (job && ["extracting", "evaluating"].includes(job.phase) && activeJob !== job.id) {
          job.phase = "interrupted";
          await chrome.storage.session.set({ job });
        }
        try {
          const grant = await target();
          return { ok: true, ready: true, report: await cachedReport(grant.tabId), interrupted: job?.phase === "interrupted" };
        } catch {
          return { ok: true, ready: false, report: null, interrupted: job?.phase === "interrupted" };
        }
      }
      case "event":
        if (typeof m.event === "string" && EVENTS.includes(m.event)) {
          await count(m.event);
          return { ok: true };
        }
        return errorResponse("INVALID_MESSAGE");
      case "clear":
        activeJob = null;
        await clearReports();
        await clearCounters();
        return { ok: true };
      default:
        return errorResponse("INVALID_MESSAGE");
    }
  };
  void run().then(sendResponse).catch(() => sendResponse(errorResponse("INTERNAL_ERROR")));
  return true;
});
