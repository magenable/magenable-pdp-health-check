// src/contracts/index.ts
var categories = ["seo", "structured", "geo", "conversion", "performance"];

// src/rules/structured-evidence.ts
function stockLine(s) {
  return `${s.channel === "unspecified" ? s.contextLabel || "Page availability" : s.channel === "delivery" ? "Delivery" : `Pickup${s.location ? " \u2014 " + s.location : ""}`}: ${s.rawText}`;
}

// src/rules/index.ts
var RULES = [
  ["SEO-01", "seo", "Page title and identity", 3, "medium"],
  ["SEO-02", "seo", "Meta description", 1, "low"],
  ["SEO-03", "seo", "H1 and heading structure", 2, "medium"],
  ["SEO-04", "seo", "Canonical declaration", 2, "medium"],
  ["SEO-05", "seo", "DOM robots directives", 3, "high"],
  ["SEO-06", "seo", "Visible product description", 3, "medium"],
  ["SEO-07", "seo", "Product image alternative text", 2, "medium"],
  ["SD-01", "structured", "Product structured data presence", 4, "high"],
  ["SD-02", "structured", "Product identity fields", 3, "medium"],
  ["SD-03", "structured", "Offer price and currency", 4, "high"],
  ["SD-04", "structured", "Availability semantics", 2, "medium"],
  ["SD-05", "structured", "Price consistency", 5, "critical"],
  ["SD-06", "structured", "Availability consistency", 4, "high"],
  ["SD-07", "structured", "Entity and variant consistency", 3, "high"],
  ["GEO-01", "geo", "Clear product identity and brand", 3, "medium"],
  ["GEO-02", "geo", "Category and intended use context", 1, "low"],
  ["GEO-03", "geo", "Specifications and attributes", 2, "medium"],
  ["GEO-04", "geo", "Readable product information", 3, "medium"],
  ["GEO-05", "geo", "Decision-support context", 1, "low", true],
  ["UX-01", "conversion", "Product imagery", 3, "medium"],
  ["UX-02", "conversion", "Visible price and stock information", 3, "medium"],
  ["UX-03", "conversion", "Primary purchase action", 4, "high"],
  ["UX-04", "conversion", "Variant option accessibility", 2, "medium"],
  ["UX-05", "conversion", "Delivery and returns information", 2, "low"],
  ["PERF-01", "performance", "Product image sizing", 2, "medium"],
  ["PERF-02", "performance", "Image dimension hints", 2, "medium"],
  ["PERF-03", "performance", "Image loading hints", 1, "low"],
  ["PERF-04", "performance", "DOM and resource complexity", 1, "low", true]
].map(([id, category, title, weight, severity, advisory]) => ({ id, category, title, weight, severity, advisory: Boolean(advisory) }));
var ruleIds = RULES.map((r) => r.id);

// src/scoring/index.ts
var DEFAULT_WEIGHTS = { seo: 25, structured: 25, geo: 20, conversion: 20, performance: 10 };
var defaultWeights = { ...DEFAULT_WEIGHTS };

// src/reports/index.ts
function summary(report2) {
  return [`PDP Health Check by Magenable | ${report2.version} / rules ${report2.ruleVersion}`, `Page origin: ${report2.origin}`, `Captured: ${report2.capturedAt}`, `Overall: ${report2.overallScore ?? "Insufficient evidence"}`, `Structured source: ${report2.structuredEvidence?.source ?? "not recorded"} (supported subset); subject: ${report2.structuredEvidence?.subject ?? "not recorded"}`, `Method: metadata/schema core; best-effort rendered observations; comparisons require independently aligned sources.`, ...report2.structuredEvidence?.subject === "group" ? ["ProductGroup family recognised; no current variant is confirmed."] : [], ...Object.entries(report2.categories).map(([k, v]) => `${k}: ${v.score ?? "Insufficient evidence"}; coverage ${v.coverage === null ? "n/a" : Math.round(v.coverage * 100) + "%"}`), `Effective weights: ${JSON.stringify(report2.effectiveWeights)}`, "", "Observed stock availability:", ...report2.stockObservations?.length ? report2.stockObservations.map(stockLine) : ["No independent visible stock statement captured."], "", ...report2.findings.filter((f) => f.status === "fail" || f.status === "warning").map((f) => `${f.ruleId} [${f.status}/${f.confidence}] ${f.title}
${f.explanation}
Evidence: ${f.evidence.join("; ")}
Recommendation: ${f.recommendation}`), "", ...report2.limitations].join("\n");
}

// src/sidepanel/index.ts
var $ = (id) => document.getElementById(id);
var status = (text) => {
  $("status").textContent = text;
};
var report = null;
var running = false;
var port = chrome.runtime.connect({ name: "panel" });
var send = (type, event2) => chrome.runtime.sendMessage({ type, ...event2 ? { event: event2 } : {} });
var event = (name) => {
  void send("event", name).catch(() => {
  });
};
function node(tag, text, parent) {
  const el = document.createElement(tag);
  el.textContent = text;
  parent.append(el);
  return el;
}
var statusLabels = { pass: "Pass", warning: "Warning", fail: "Fail", not_evaluated: "Not Evaluated" };
var statusHelp = { pass: "The assessed criteria were met; this is not a complete audit guarantee.", warning: "An issue or improvement needs review. Check the evidence and confidence.", fail: "Available evidence supports a problem with the assessed criteria.", not_evaluated: "Not enough reliable evidence to assess this check; not counted as a pass or fail." };
var labels = { seo: "SEO", structured: "Structured Data", geo: "AI Discoverability", conversion: "Conversion UX", performance: "Local Technical Observations" };
function render(r) {
  report = r;
  $("report").hidden = false;
  $("overall").textContent = `Overall: ${r.overallScore ?? "Insufficient evidence"}`;
  const configuredTotal = Object.values(r.configuredWeights).reduce((sum, w) => sum + w, 0);
  const coverage = categories.reduce((sum, c) => sum + (r.categories[c].coverage ?? 0) * r.configuredWeights[c], 0) / configuredTotal;
  $("overall-evidence").textContent = `Evidence coverage: ${Math.round(coverage * 100)}% across configured categories. Scores apply only to evaluated checks, not a complete professional audit.${r.overallScore === null && r.classification === "product" ? " No overall score: SEO, structured data and at least one readiness category must meet their coverage gates. Individual findings remain useful." : ""}`;
  $("page").textContent = `Page origin: ${r.origin}`;
  $("capture").textContent = `Captured ${r.capturedAt} \xB7 rules ${r.ruleVersion}. Cached results are not a new scan.`;
  $("weights").textContent = "Effective weights: " + Object.entries(r.effectiveWeights).map(([k, v]) => `${labels[k]} ${Math.round(v)}%`).join(", ");
  const source = r.structuredEvidence;
  $("structured-source").textContent = source ? `Subject: ${source.subject === "group" ? "ProductGroup family \u2014 current variant not confirmed" : source.subject === "product" ? "matched Product" : "no uniquely matched subject"} \xB7 ${source.jsonldGroups ?? 0} ProductGroup families. Structured evidence: ${source.source === "none" ? "no uniquely matched Product" : source.source === "microdata" ? "Microdata \u2014 supported subset" : "JSON-LD \u2014 core Product/Offer checks"} \xB7 ${source.jsonldProducts} JSON-LD / ${source.microdataProducts} microdata Product candidates. Not full rich-result validation.` : "";
  $("stock-observations").replaceChildren();
  for (const observation of r.stockObservations ?? []) node("li", `${stockLine(observation)} \xB7 ${observation.confidence} confidence \xB7 visible page evidence`, $("stock-observations"));
  if (!r.stockObservations?.length) node("li", "No independent visible stock statement captured. Structured data and an enabled button are not substituted for visible stock.", $("stock-observations"));
  const actionable = r.findings.filter((f) => (f.status === "fail" || f.status === "warning") && !f.advisory && f.confidence !== "low");
  $("issues").textContent = `${actionable.length} scored ${actionable.length === 1 ? "issue" : "issues"}. Advisory and unavailable findings are separate.`;
  $("priorities").replaceChildren();
  for (const f of actionable.slice(0, 5)) node("li", `${f.title}: ${f.recommendation}`, $("priorities"));
  if (!actionable.length) node("li", "No scored issues found in available evidence. Review coverage and limitations.", $("priorities"));
  $("categories").replaceChildren();
  for (const category of categories) {
    const c = r.categories[category];
    const section = node("details", "", $("categories"));
    node("summary", `${labels[category]}: ${c.score ?? "Not scored"} \xB7 ${c.evaluatedCount} evaluated \xB7 coverage ${c.coverage === null ? "n/a" : Math.round(c.coverage * 100) + "%"}`, section);
    if (c.score === null) {
      const needed = [];
      if (c.evaluatedCount < 2) needed.push("at least 2 evaluated checks");
      if (c.coverage === null || c.coverage < 0.5) needed.push("at least 50% evidence coverage");
      node("p", `No numeric score: this category needs ${needed.join(" and ")}. Useful observations are still listed below.`, section);
    } else if (c.coverage !== null && c.coverage < 1) {
      node("p", `Based on available evidence only (${Math.round(c.coverage * 100)}% coverage). Unavailable checks are not passes or failures.`, section);
    }
    for (const f of r.findings.filter((x) => x.category === category)) {
      const item = node("details", "", section);
      item.className = `finding-${f.status}`;
      const findingSummary = node("summary", `${f.applicability === "not_applicable" ? "Not Applicable" : statusLabels[f.status]} \xB7 ${f.title}`, item);
      findingSummary.title = f.applicability === "not_applicable" ? "This check does not apply to this page; excluded from scoring and evidence coverage." : statusHelp[f.status];
      node("p", `Method: ${f.method === "standard" ? "Standards / metadata" : f.method === "comparison" ? "Cross-source comparison" : f.method === "rendered" ? "Rendered observation \u2014 best effort" : "not recorded in cached report"}`, item);
      node("p", `Severity: ${f.severity} \xB7 Confidence: ${f.confidence} \xB7 ${f.advisory ? "Advisory only" : f.applicability}`, item);
      node("p", f.explanation, item);
      node("pre", f.evidence.join("\n") || "No reliable evidence available.", item);
      node("p", `Recommendation: ${f.recommendation}`, item);
      node("p", `${f.ruleId} \xB7 ${f.reasonCode}`, item);
      item.addEventListener("toggle", () => {
        if (item.open) event("finding_expanded");
      });
    }
  }
  $("limitations").replaceChildren();
  for (const text of r.limitations) node("li", text, $("limitations"));
  $("analyse").textContent = "Reanalyse This Page";
}
var errors = { ACCESS_BLOCKED: "The website is showing an access/security verification screen, not a product page. Load the normal product page in your browser, then analyse again. No challenge is bypassed.", ACTION_REQUIRED: "Click the extension icon on this product tab to enable analysis, then try again.", UNSUPPORTED_PAGE: "This page cannot be inspected. Open a normal HTTP(S) product page.", INTERRUPTED: "Analysis was interrupted by a page or permission change. Click the extension icon and reanalyse.", BUSY: "Another audit is still running. Wait or clear it.", ANALYSIS_FAILED: "Analysis failed or permission expired. Click the extension icon on the product tab and try again.", INVALID_SNAPSHOT: "The page returned unsupported or excessive data. No report was saved." };
$("analyse").addEventListener("click", async () => {
  if (running) return;
  running = true;
  $("analyse").disabled = true;
  status("Extracting this page and evaluating available evidence\u2026");
  try {
    const result = await send("analyse");
    if (result.ok) {
      render(result.report);
      status(result.report.classification === "non_product" ? "No product page detected. Product-specific checks were not evaluated." : result.report.classification === "ambiguous" ? "Product page identity is unconfirmed. Product-specific checks were not evaluated." : "Analysis complete. Review evidence and coverage; unavailable comparisons remain unscored.");
    } else {
      report = null;
      $("report").hidden = true;
      status(errors[result.error] ?? "Unable to analyse this page. Reopen the extension and retry.");
    }
  } catch {
    status("Extension connection interrupted. Reopen the panel and try again.");
  } finally {
    running = false;
    $("analyse").disabled = false;
  }
});
$("clear").addEventListener("click", async () => {
  await send("clear");
  report = null;
  $("report").hidden = true;
  status("Results and local counters cleared.");
});
$("copy").addEventListener("click", async () => {
  if (!report) return;
  try {
    await navigator.clipboard.writeText(summary(report));
    event("report_copied");
    status("Summary copied. Review evidence before sharing.");
  } catch {
    status("Clipboard unavailable. Use Export text instead.");
  }
});
function download(format) {
  if (!report) return;
  const blob = new Blob([format === "json" ? JSON.stringify(report, null, 2) : summary(report)], { type: format === "json" ? "application/json" : "text/plain" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `magenable-pdp-report.${format === "json" ? "json" : "txt"}`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1e3);
  event("report_exported");
  status("Report exported. Origin only; review evidence before sharing.");
}
$("text").addEventListener("click", () => download("text"));
$("json").addEventListener("click", () => download("json"));
$("website").addEventListener("click", () => event("website_clicked"));
$("consult").addEventListener("click", () => event("consultation_clicked"));
for (const category of categories) {
  const label = node("label", labels[category] + " ", $("weight-inputs"));
  const input = document.createElement("input");
  input.id = "weight-" + category;
  input.type = "number";
  input.min = "0";
  input.max = "100";
  input.step = "0.1";
  label.append(input);
  label.style.display = "block";
}
function displayWeights(weights) {
  for (const category of categories) $("weight-" + category).value = String(weights[category]);
}
async function saveWeights(weights) {
  const result = await chrome.runtime.sendMessage({ type: "set_weights", weights });
  status(result.ok ? "Weights saved. Reanalyse to apply; existing reports are unchanged." : "Invalid weights. Use numbers from 0 to 100 with at least one positive value.");
  if (result.ok) displayWeights(result.weights);
}
$("save-weights").addEventListener("click", () => {
  void saveWeights(Object.fromEntries(categories.map((c) => [c, Number($("weight-" + c).value)])));
});
$("reset-weights").addEventListener("click", () => {
  void saveWeights({ seo: 25, structured: 25, geo: 20, conversion: 20, performance: 10 });
});
void send("get_weights").then((result) => displayWeights(result.weights)).catch(() => {
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "session" && changes.grant) {
    report = null;
    $("report").hidden = true;
    status(changes.grant.newValue ? "Ready on the selected tab. Click Analyse to read the page." : "Page changed or access expired. Click the extension icon on the product tab before reanalysing.");
  }
});
void send("init").then((data) => {
  if (data.report) render(data.report);
  status(data.interrupted ? "Previous analysis was interrupted. Click Analyse to start a fresh scan." : data.ready ? "Ready. Analysis begins only when you click Analyse." : "Click the extension icon on the product tab, then Analyse.");
  event("extension_opened");
}).catch(() => status("Extension not available. Reload the panel."));
